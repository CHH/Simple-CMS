<?php

class PluginLoadException extends Exception
{}