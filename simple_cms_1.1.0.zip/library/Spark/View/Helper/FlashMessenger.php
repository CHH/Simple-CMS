<?php

class Spark_View_Helper_FlashMessenger extends Zend_View_Helper_Abstract
{
  
  protected $_sessionNamespace = null;
  
  public function __construct()
  {
    
  }
  
  public function flashMessenger()
  {
    
  }
  
}
