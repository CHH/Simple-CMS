<?php

class PluginException extends Exception
{}