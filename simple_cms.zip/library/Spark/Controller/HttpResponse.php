<?php

class Spark_Controller_HttpResponse extends Zend_Controller_Response_Http
{
  
}