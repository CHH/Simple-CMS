<?php

class Spark_Controller_Exception extends Spark_Exception
{}