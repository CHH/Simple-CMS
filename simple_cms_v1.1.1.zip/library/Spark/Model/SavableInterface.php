<?php

interface Spark_Model_SavableInterface
{
  
  public function asSavable();
  
}