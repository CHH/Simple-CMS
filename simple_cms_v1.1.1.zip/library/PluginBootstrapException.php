<?php

class PluginBootstrapException extends Exception
{}